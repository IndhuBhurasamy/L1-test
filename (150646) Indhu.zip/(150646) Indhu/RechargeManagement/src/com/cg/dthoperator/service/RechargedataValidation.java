/******Author Name:Indhu Emp Id :150646 Date:05.07.2018
//Purpose: To provide data validation for the user input

package com.dthoperator.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RechargeDataValidator {
		//validating dth operator 

		public boolean validatedthOperator(int dthOperator)
		{
			Pattern p = Pattern.compile("[0-9]{1}");
			String a=Integer.toString(dthOperator);
			Matcher m = p.matcher((a));
			return m.matches();
			
		}
		//validate consumer no - it should not exceed more than 10 and less than 10

		public boolean validateConsumerNo(int consumerNo)
		{
			Pattern p =Pattern.compile("[0-9]+{10}");
			String a=Integer.toString(consumerNo);
			Matcher m = p.matcher((a));
			return m.matches();
			
		}
		//validating plan 

		public boolean validatePlan(int plan)
		{
			Pattern  p= Pattern.compile("[0-9]{1}");
			String a=Integer.toString(plan);
			Matcher m = p.matcher((a));
			return m.matches();
		}
		//validate amount - it can be minimum of three digit and maximum of four digit

		public boolean validateAmount(int amount)
		{
			Pattern p =Pattern.compile("[0-9]+{3,}");
			String a=Integer.toString(amount);
			Matcher m = p.matcher((a));
			return m.matches();
			
		}
}

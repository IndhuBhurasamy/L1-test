/******* Author Name: Indhu Emp Id : 150646  Date:07.5.2018 ******/
//Purpose: To define exceptions for invalid input

package com.dthoperator.exception;

public class ListException extends Exception{
	
	String message;
	//validating exception
	public ListException()
	{
		this.message="Data is not found.";     
		
	}
   
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}

/****** Author Name: Indhu Emp Id:150646 Date:05.07.2018*******/
//Purpose: To provide user interface of Recharge Management for accepting & displaying Recharge details

package com.dthoperator.ui;
import java.util.Scanner;
import java.util.ArrayList;
import com.dthoperator.bean.RechargeDetails;
import com..service.RechargecollectionHelper;
import com.dthoperator.service.RechargedataValidator;


public class RechargeClient {

//Main method

	public static void main(String[] args) throws com.dthoperator.exception.ListException {
		
// TODO Auto-generated method stub

		RechargeCollectionHelper r1 = new RechargecollectionHelper();
		RechargeDataValidator data = new RechargedataValidator();
		ArrayList<RechargeDetails> detail = new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		char ans=' ';
		System.out.println("Menu\n1. Enter a Recharge Details \n2.Display Recharge Details\n3. Exit");
		int option = sc.nextInt();
		switch (option) {
		case 1:
//to select the valid  dth operator for the valid input
			
                                                     System.out.println("Select DTH Operator:\n1.Airtel\n2.DishTV\n3.Reliance\n4.TATASky\n");
			int opt1=0;
			opt1= sc.nextInt();
			if(opt1<4)
			{
			while(!data.validatedthOperator(opt1))
			{
				opt1 = sc.nextInt();                                       
			}
			}
			else
			{
				System.out.println("Enter the correct choice");                                     
				break;                                           
			}


//To enter the valid consumer number 
			
                                                  System.out.println("Enter Consumer No.:\n");
			int conNum= 0;
			conNum= sc.nextInt();
			if(conNum == 1089343431 || conNum == 303322123)
			{
			while(!data.validateConsumerNo(conNum))
			{
				conNum= sc.nextInt();
			}
			}
			else
			{
				System.out.println("Data is not found.");
				break;
			}
			
    //To select a recharge plan for the valid input
                    
		            System.out.println("Select Plan:\n1.Monthly\n2.Quarterly\n3.Half Yearly\n4.Annual\n");
			int plan = 0;
			plan = sc.nextInt();
			while(!data.validatePlan(plan))
			{
				plan = sc.nextInt();
			}
          //Sending input to validateAmount method for validating amount

			System.out.println("Enter Amount (Rs.):\n");
			int amount = 0;
			amount = sc.nextInt();
			while(!data.validateAmount(amount))
			{
				amount = sc.nextInt();
			}
			System.out.println("Successful Recharge.Transaction ID is:\n");
			int i=1234;
			int a=4;
			if(i%(a+2)==5)
			{
				i=2345;
				System.out.println(i);
			}
			else if(i%(a+1)==0)
			{
				i=2599;
				System.out.println(i);
			}
			else
			{
				i=2586;
				System.out.println(i);
			}	
			break;
			
			
		case 2:
			
                    //To display the details 

			ArrayList<RechargeDetails> list = r1.getItems();
			for(RechargeDetails rechargeDetails : list)
				System.out.println(rechargeDetails);
			break;
		
		                 case 3:
			
                 //To exit the application

			System.out.println("Exit");
			break;
			
		default:
			System.out.println("Enter the correct choice\n");
			break;
		}
		
		
	}

}

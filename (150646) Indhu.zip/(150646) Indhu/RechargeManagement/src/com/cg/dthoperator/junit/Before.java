/******* Author Name: Indhu Emp Id : 150646  Date:05.07.2018 ******/

package com.dthoperator.junit;

@interface Before {

}

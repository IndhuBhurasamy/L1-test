package com.capgemini.lesson7.abstractdemo;

public abstract class Spicy extends Food {

	public Spicy()
	{
		System.out.println("IS SPICY");
	}
	
	@Override
	public String taste() {
		// TODO Auto-generated method stub
		return "Spicy";
	}

}




public class  AbstractBase {
    final void fun() { System.out.println("Derived fun() called"); }
}
  
public class Derived extends Base {}
  
class Main {
    public static void main(String args[]) { 
       Base b = new Derived();
       b.fun();
    }
} 
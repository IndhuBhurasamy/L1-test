package com.capgemini.lesson3.operators;

public class TernaryOperator {

	/**
	 * @param args
	 */
	  public static void main(String[] args) {
		    int v = 1;
		    System.out.println(v == 1 ? "A" : "B");

		    v++;
		    System.out.println(v == 1 ? "A" : "B");
		  }
}
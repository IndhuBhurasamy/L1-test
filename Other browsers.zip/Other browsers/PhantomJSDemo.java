package neww;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;   

public class PhantomJSDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("phantomjs.binary.path", "D:/selenium jars/phantomjs.exe");
        WebDriver driver = new PhantomJSDriver();
                  
        driver.get("http://demo.opencart.com/");
        //driver.get("file:///D:/SeleniumWebDriverAT/Lesson05/src/AlertExample.html");
        System.out.println("Page title is: " + driver.getTitle());      
        
        driver.quit();         

	}

}


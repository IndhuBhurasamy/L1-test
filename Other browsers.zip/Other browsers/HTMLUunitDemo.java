package neww;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class HTMLUunitDemo {

	public static void main(String[] args) {

	    //WebDriver driver = new HtmlUnitDriver();
		WebDriver driver = new HtmlUnitDriver();
	driver.get("file:///D:/Users/chenitha/Desktop/Test Automation & Adv. Selenium/Manual demos/Demo/Lesson 5-HTML Pages/WorkingWithForms.html");
	  // driver.get("http://www.google.com");;
		String str=driver.getTitle();
      System.out.println(driver.getCurrentUrl());
       System.out.println("Page title is: " + str); 
	}

}

package SeleniumPackage;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriver {
	
		public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.firefox.bin",
				"C:/Users/chenitha/AppData/Local/Mozilla Firefox/firefox.exe");
        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("network.proxy.type", 1);
        profile.setPreference("network.proxy.http", "10.219.96.26");
        profile.setPreference("network.proxy.http_port", 8080);
        profile.setPreference("network.proxy.ssl", "10.219.96.26");
        profile.setPreference("network.proxy.ssl_port", 8080);
        FirefoxDriver driver = new FirefoxDriver(profile);
//   	    driver = new FirefoxDriver();
        
        String baseUrl = "file:///D:/example-javascript-form-validation.html";
        String expectedtitle = "JavaScript Form Validation using a sample registration form";
        String actualtitle;
        driver.get(baseUrl);
        actualtitle = driver.getTitle();
        
        
        if(actualtitle.contentEquals(expectedtitle))
        {
        	System.out.println("Title Test Passed");
        	
        }
        else
        {
        	System.out.println("Title Test failed");
        	driver.close();
        }
        
        driver.findElement(By.xpath(".//*[@id='usrID']")).sendKeys("Abcdefg");

  		//Find Password textbox and enter value
  		driver.findElement(By.xpath(".//*[@id='pwd']")).sendKeys("chris@123");
  		
  		Thread.sleep(1000);
  		//Find Confirm Password textbox and enter value
  		driver.findElement(By.xpath(".//*[@id='usrname']")).sendKeys("ghijk");
  		Thread.sleep(1000);  		 		
  		//Find First Name textbox and enter value
  		driver.findElement(By.xpath(".//*[@id='addr']")).sendKeys("Anna Salai");
  		//driver.findElementById(using)
  		Thread.sleep(1000);
  		new Select(driver.findElement(By.xpath("html/body/form/ul/li[10]/select"))).selectByVisibleText("India");
  		
  		driver.findElement(By.xpath("html/body/form/ul/li[12]/input")).sendKeys("123456");
  		
  		//Find Gender radio button and enter value
  		driver.findElement(By.xpath("html/body/form/ul/li[14]/input")).sendKeys("abc@xyz.com");;
  		
  		//Find Date Of Birth textbox and enter value
  		driver.findElement(By.xpath("html/body/form/ul/li[16]/input")).click();
  		
  		
  		//Find Email textbox and enter value
  		driver.findElement(By.xpath("html/body/form/ul/li[19]/input")).click();
  		
  		//Find Address textbox and enter value
  		driver.findElement(By.xpath(".//*[@id='desc']")).sendKeys("6LotusPond");

       
        if(driver.findElement(By.xpath(".//*[@id='usrID']")).isDisplayed())
        {
        	System.out.println("User Id test passed");
        }
        
        if(driver.findElement(By.xpath(".//*[@id='pwd']")).isDisplayed())
        {
        	System.out.println("Password test passed");
        }
        
        if(driver.findElement(By.xpath(".//*[@id='usrname']")).isDisplayed())
        {
        	System.out.println("Name test passed");
        }
        
        if(driver.findElement(By.xpath(".//*[@id='addr']")).isDisplayed())
        {
        	System.out.println("Address test passed");
        }
        
        if(driver.findElement(By.xpath("html/body/form/ul/li[10]/select")).isDisplayed())
        {
        	System.out.println("Country test passed");
        }
        
        if(driver.findElement(By.xpath("html/body/form/ul/li[12]/input")).isDisplayed())
        {
        	System.out.println("Zip Code test passed");
        }
        
        if(driver.findElement(By.xpath("html/body/form/ul/li[14]/input")).isDisplayed())
        {
        	System.out.println("Email test passed");
        }
        
       if(driver.findElement(By.xpath("html/body/form/ul/li[23]/input")).isDisplayed())
        {
        	System.out.println("Address test passed");
        }
        
        if(driver.findElement(By.xpath(".//*[@id='gender']")).isDisplayed())
        {
        	System.out.println("Gender test passed");
        }
        
        if(driver.findElement(By.xpath("html/body/form/ul/li[18]/label")).isDisplayed())
        {
        	System.out.println("language test passed");
        }
        
        if(driver.findElement(By.xpath("html/body/form/ul/li[21]/label")).isDisplayed())
        {
        	System.out.println("About test passed");
        }
		 //Thread.sleep(4000);
  		 
   	    if ( driver.findElement(By.xpath("html/body/form/ul/li[19]/input")).isSelected() )		//xpath of the checkbox which you have to select 
   	    {
   	        System.out.println("English is selected");					//English is not present 
   	        
   	    }
   	    else
   	    {
   	    	System.out.println("English is not selected") ;
   	    }
   	
   	
   		
   		
//Thread.sleep(5000);	//wait for 4 sec
Select dropdown = new Select(driver.findElement(By.xpath("html/body/form/ul/li[10]/select")));
//Thread.sleep(2000) ;

dropdown.selectByVisibleText("India");

if (driver.findElement(By.xpath("html/body/form/ul/li[10]/select")).isDisplayed())	//xpath of the dropdown option which you have to select 
{
 System.out.println("India is selected");					// is not present 
 
}
else
{
	System.out.println("India is not selected") ;
}


if ( driver.findElement(By.xpath("html/body/form/ul/li[17]/input")).isSelected() )		//xpath of the Radio Button which you have to select 
{
 System.out.println("Female is selected");					// is not present 
 
}
else
{
	System.out.println("Female is not selected") ;
}      

//checkBox3 = driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input[3]"));
driver.findElement(By.xpath("html/body/form/ul/li[23]/input")).click();
      
      //Find Username textbox and enter value
//      		driver.findElement(By.xpath("html/body/form/ul/li[23]/input")).click();
      		
  Alert alert=driver.switchTo().alert();
  Thread.sleep(3000);
  alert.accept();
              			
          driver.close();
          System.exit(0);
	}
}
package SeleniumPackage;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;

public class Registration {

	private static Alert alert;

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.firefox.bin", "C:/Users/chenitha/AppData/Local/Mozilla Firefox/firefox.exe");
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", "chnproxy.igate.com");
		profile.setPreference("network.proxy.http_port", 8080);
		profile.setPreference("network.proxy.ssl", "chnproxy.igate.com");
		profile.setPreference("network.proxy.ssl_port", 8080);
		FirefoxDriver driver = new FirefoxDriver(profile);

		// verification of title of the page
		String baseUrl = "file:///D:/my hello/ConferenceRegistartion.html";
		String expectedtitle = "Conference Registartion";
		String actualtitle;
		driver.get(baseUrl);
		actualtitle = driver.getTitle();

		if (actualtitle.contentEquals(expectedtitle)) {
			System.out.println("Title Test Passed");

		} else {
			System.out.println("Title Test failed");
			driver.close();
		}
		
		// Find First name textbox and enter value
		driver.findElement(By.xpath(".//*[@id='txtFirstName']")).sendKeys(
				"SURYA"); Thread.sleep(1000);
		// Find Last name textbox and enter value
				driver.findElement(By.xpath(".//*[@id='txtLastName']")).sendKeys(
						"SIVAMOHAN"); Thread.sleep(1000);
		
		// Find Email textbox and enter value
		driver.findElement(By.xpath(".//*[@id='txtEmail']")).sendKeys(
				"msmsnaveen@gmail.com"); Thread.sleep(1000);
		
		// Find Contact Number textbox and enter value
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys(
				"7893806402"); Thread.sleep(1000);

		// clicking on dropdown list of NO Of people attending
		Select NO = new Select(driver.findElement(By
				.xpath("html/body/form/table/tbody/tr[5]/td[2]/select")));
		NO.selectByVisibleText("3"); Thread.sleep(1000);

		// Find addressbox and enter value
		driver.findElement(By.xpath(".//*[@id='txtAddress']")).sendKeys(
				"11-192"); Thread.sleep(1000);
		// Find addressbox2 and enter value
		driver.findElement(By.xpath(".//*[@id='txtAddress2']")).sendKeys(
				"11-192"); Thread.sleep(1000);
		// clicking on dropdown list of City
		Select City = new Select(driver.findElement(By
				.xpath("html/body/form/table/tbody/tr[9]/td[2]/select")));
		City.selectByVisibleText("Mumbai"); Thread.sleep(1000);

		// clicking on dropdown list of state
		Select state = new Select(driver.findElement(By
				.xpath("html/body/form/table/tbody/tr[10]/td[2]/select")));
		state.selectByVisibleText("Maharashtra"); Thread.sleep(1000);

		// clicking on the access button
		driver.findElement(
				By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input"))
				.click();
		// clicking on the NextButton

		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a"))
				.click();
		//alert.accept();

	}}
